import React from 'react';
import { Outlet } from 'react-router-dom';

const AuthLayout = () => {
    return React.createElement(Outlet);
};

export default AuthLayout; 