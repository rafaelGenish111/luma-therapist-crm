export { default as Home } from './Home';
export { default as About } from './About';
export { default as Articles } from './Articles';
export { default as Gallery } from './Gallery';
export { default as BookAppointment } from './BookAppointment';
export { default as Contact } from './Contact';
export { default as WebsiteLayout } from './WebsiteLayout'; 