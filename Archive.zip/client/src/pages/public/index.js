// ייצוא כל הדפים הציבוריים
export { default as AboutPage } from './AboutPage';
export { default as ServicesPage } from './ServicesPage';
export { default as GalleryPage } from './GalleryPage';
export { default as TestimonialsPage } from './TestimonialsPage';
export { default as ContactPage } from './ContactPage';


